var john = {
    name: 'John',
    age: 22,
    hobby: ['baking', 'horse riding']
};
console.log(john);
