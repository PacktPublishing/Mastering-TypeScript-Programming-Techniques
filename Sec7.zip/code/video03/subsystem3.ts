export class Fraud {
  checkFraud(): boolean {
    return false;
  }
}