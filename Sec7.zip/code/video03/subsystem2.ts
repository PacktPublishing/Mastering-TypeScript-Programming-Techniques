export class BackgroundCheck {
  criminalRecords(): boolean {
    return false;
  }
}