export class Funds {
  checkFunds(): boolean {
    return true;
  }
}