import { Facade } from './facade';

const facade: Facade = new Facade();
facade.checkEligibility();