export class Observer1 {
  constructor(data) {
    console.log(`Observer1 -- Data received from subject: ${data}`);
  }
}

export class Observer2 {
  constructor(data) {
    console.log(`Observer2 -- Data received from subject: ${data}`);
  }
}

export class Observer3 {
  constructor(data) {
    console.log(`Observer3 -- Data received from subject: ${data}`);
  }
}