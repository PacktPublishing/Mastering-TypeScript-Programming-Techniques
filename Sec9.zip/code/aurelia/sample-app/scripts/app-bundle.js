define('app',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var App = (function () {
        function App() {
        }
        return App;
    }());
    exports.App = App;
});



define('environment',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = {
        debug: true,
        testing: true
    };
});



define('first',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    ;
    var First = (function () {
        function First() {
            var _this = this;
            fetch('http://localhost:3000/api/products')
                .then(function (response) { return response.json(); })
                .then(function (products) { return _this.products = products; });
        }
        return First;
    }());
    exports.First = First;
});



define('main',["require", "exports", "./environment"], function (require, exports, environment_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function configure(aurelia) {
        aurelia.use
            .standardConfiguration()
            .feature('resources');
        if (environment_1.default.debug) {
            aurelia.use.developmentLogging();
        }
        if (environment_1.default.testing) {
            aurelia.use.plugin('aurelia-testing');
        }
        aurelia.start().then(function () { return aurelia.setRoot(); });
    }
    exports.configure = configure;
});



define('resources/index',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function configure(config) {
    }
    exports.configure = configure;
});



define('text!app.html', ['module'], function(module) { module.exports = "<template><require from=\"./first\"></require><h1>Product list</h1><first></first></template>"; });
define('text!first.html', ['module'], function(module) { module.exports = "<template><ul><li repeat.for=\"product of products\">${product.name} costs £${product.price}</li></ul></template>"; });
//# sourceMappingURL=app-bundle.js.map