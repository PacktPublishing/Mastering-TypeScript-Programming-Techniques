// import { methodDecorator, paramDecorator } from './parameter-decorator-functions'
// class Hero {
//   public name: string;
//   constructor() { }
//   @methodDecorator
//   greet(@paramDecorator name: string): string {
//     return `Hi, I am ${name}.`;
//   }
// }

// const myHero = new Hero();
// console.log(myHero.greet('Superman'));